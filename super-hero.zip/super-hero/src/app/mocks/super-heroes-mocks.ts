import { ISuperHero, ISuperHeroEdition } from '../shared/models/interfaces/super-hero.interface';

export const superHeroesMocks: ISuperHero[] = [
    {
        name: 'SUPER MAN',
        description: 'Fly',
        id: 1,
    },
    {
        name: 'SPIDER MAN',
        description: 'Spider',
        id: 2,
    },
    {
        name: 'THOR',
        description: 'A soon of a god',
        id: 3,
    },
    {
        name: 'IRON MAN',
        description: 'A rich guy',
        id: 4,
    },
    {
        name: 'BLACK WIDOW',
        description: 'A super woman',
        id: 5,
    },
    {
        name: 'HULK',
        description: 'A big green man (like shrek)',
        id: 6,
    },
];
export const superHero1: ISuperHero = {
    name: 'SUPER MAN',
    description: 'Fly',
    id: 1,
};
export const superHeroFormMock: ISuperHeroEdition = {
    name: 'SUPER MAN',
    description: 'Fly',
};
export const searchSuperHeroByName: ISuperHero[] = [
    {
        name: 'SUPER MAN',
        description: 'Fly',
        id: 1,
    },
];

export const searchSuperHeroByNameAndId: ISuperHero[] = [
    {
        name: 'SUPER MAN',
        description: 'Fly',
        id: 1,
    },
];
