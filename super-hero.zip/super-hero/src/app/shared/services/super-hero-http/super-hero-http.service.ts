import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError, Observable, throwError } from 'rxjs';
import { ISuperHero, ISuperHeroEdition } from '../../models/interfaces/super-hero.interface';
import { environment } from '../../../../environments/environment';

@Injectable({
    providedIn: 'root',
})
export class SuperHeroHttpService {
    constructor(private readonly httpClient: HttpClient) {}

    public getAllSuperHeroes(): Observable<ISuperHero[]> {
        return this.httpClient.get<ISuperHero[]>(environment.httpServer + '/super-heroes').pipe(
            catchError((error: HttpErrorResponse): Observable<never> => {
                return throwError(() => error);
            })
        );
    }

    public getHeroById(id: number): Observable<ISuperHero> {
        return this.httpClient.get<ISuperHero>(environment.httpServer + `/super-heroes/${id}`).pipe(
            catchError((error: HttpErrorResponse): Observable<never> => {
                return throwError(() => error);
            })
        );
    }

    public searchHeroesByQuery(name: string, id: string): Observable<ISuperHero[]> {
        const nameQuery: string = name ? `name_like=${name.trim()}` : '';
        const idQuery: string = id ? `id=${id.trim()}` : '';

        return this.httpClient
            .get<ISuperHero[]>(
                environment.httpServer + `/super-heroes?${nameQuery}${idQuery && nameQuery ? '&' + idQuery : idQuery}`
            )
            .pipe(
                catchError((error: HttpErrorResponse): Observable<never> => {
                    return throwError(() => error);
                })
            );
    }

    public createSuperHero(hero: ISuperHeroEdition): Observable<ISuperHero> {
        return this.httpClient.post<ISuperHero>(environment.httpServer + '/super-heroes', hero).pipe(
            catchError((error: HttpErrorResponse): Observable<never> => {
                return throwError(() => error);
            })
        );
    }

    public editSuperHero(hero: ISuperHeroEdition, id: number): Observable<ISuperHero> {
        return this.httpClient.put<ISuperHero>(environment.httpServer + `/super-heroes/${id}`, hero).pipe(
            catchError((error: HttpErrorResponse): Observable<never> => {
                return throwError(() => error);
            })
        );
    }

    public deleteSuperHero(id: number): Observable<ISuperHero> {
        return this.httpClient.delete<ISuperHero>(environment.httpServer + `/super-heroes/${id}`).pipe(
            catchError((error: HttpErrorResponse): Observable<never> => {
                return throwError(() => error);
            })
        );
    }
}
