import { TestBed } from '@angular/core/testing';

import { SuperHeroHttpService } from './super-hero-http.service';
import { HttpClientTestingModule, HttpTestingController, TestRequest } from '@angular/common/http/testing';
import { HttpErrorResponse } from '@angular/common/http';
import { NEVER } from 'rxjs/internal/observable/never';
import { catchError } from 'rxjs/internal/operators/catchError';
import { Observable } from 'rxjs/internal/Observable';
import { ISuperHero } from '../../models/interfaces/super-hero.interface';
import { searchSuperHeroByName, superHero1, superHeroesMocks } from '../../../mocks/super-heroes-mocks';

describe('SuperHeroHttpServiceService', (): void => {
    let service: SuperHeroHttpService;
    let httpController: HttpTestingController;

    let url: string = 'http://localhost:3000/';

    beforeEach((): void => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
        });
        service = TestBed.inject(SuperHeroHttpService);
        httpController = TestBed.inject(HttpTestingController);
    });

    describe('getAllSuperHeroes()', (): void => {
        it('should call getAllSuperHeroes and return an array of Super Heroes', (): void => {
            service.getAllSuperHeroes().subscribe((res: ISuperHero[]): void => {
                expect(res).toEqual(superHeroesMocks);
            });

            const req: TestRequest = httpController.expectOne({
                method: 'GET',
                url: `${url}super-heroes`,
            });

            req.flush(superHeroesMocks);
        });

        it('getUsers() return an error when the server returns a 404 error', (): void => {
            service
                .getAllSuperHeroes()
                .pipe(
                    catchError((error: HttpErrorResponse): Observable<never> => {
                        expect(error).toEqual(error);
                        return NEVER;
                    })
                )
                .subscribe();

            httpController
                .expectOne({
                    method: 'GET',
                })
                .flush('', {
                    status: 404,
                    statusText: 'Not Found',
                });
        });
    });

    describe('getHeroById()', (): void => {
        it('should call getHeroById and return the appropriate Super hero', (): void => {
            const id = 1;

            service.getHeroById(id).subscribe((data: ISuperHero) => {
                expect(data).toEqual(superHero1);
            });

            const req: TestRequest = httpController.expectOne({
                method: 'GET',
                url: `${url}super-heroes/${id}`,
            });

            req.flush(superHero1);
        });

        it('getHeroById() return an error when the server returns a 404 error', (): void => {
            service
                .getHeroById(1)
                .pipe(
                    catchError((error: HttpErrorResponse): Observable<never> => {
                        expect(error).toEqual(error);
                        return NEVER;
                    })
                )
                .subscribe();

            httpController
                .expectOne({
                    method: 'GET',
                })
                .flush('', {
                    status: 404,
                    statusText: 'Not Found',
                });
        });
    });

    describe('searchHeroesByQuery()', (): void => {
        it('should call searchHeroesByQuery let empty id and fill the name and return the super hero', (): void => {
            const nameQuery: string = 'sup';

            service.searchHeroesByQuery(nameQuery, '').subscribe((data: ISuperHero[]) => {
                expect(data).toEqual(searchSuperHeroByName);
            });

            const req: TestRequest = httpController.expectOne({
                method: 'GET',
                url: `${url}super-heroes?name_like=${nameQuery}`,
            });

            req.flush(searchSuperHeroByName);
        });

        it('should call searchHeroesByQuery fill name and id return the super hero', (): void => {
            const nameQuery: string = 'sup';
            const id: string = '1';

            service.searchHeroesByQuery(nameQuery, id).subscribe((data: ISuperHero[]) => {
                expect(data).toEqual(searchSuperHeroByName);
            });

            const req: TestRequest = httpController.expectOne({
                method: 'GET',
                url: `${url}super-heroes?name_like=${nameQuery}&id=${id}`,
            });

            req.flush(searchSuperHeroByName);
        });

        it('searchHeroesByQuery() return an error when the server returns a 404 error', (): void => {
            service
                .searchHeroesByQuery('sup', '')
                .pipe(
                    catchError((error: HttpErrorResponse): Observable<never> => {
                        expect(error).toEqual(error);
                        return NEVER;
                    })
                )
                .subscribe();

            httpController
                .expectOne({
                    method: 'GET',
                })
                .flush('', {
                    status: 404,
                    statusText: 'Not Found',
                });
        });
    });

    describe('createSuperHero()', (): void => {
        it('should call createSuperHero  and create super hero', (): void => {
            const hero: ISuperHero = {
                name: 'super man',
                description: 'A men with spider powers',
                id: 1,
            };

            service.createSuperHero(hero).subscribe((data: ISuperHero): void => {
                expect(data).toEqual(superHero1);
            });

            const req: TestRequest = httpController.expectOne({
                method: 'POST',
                url: `${url}super-heroes`,
            });

            req.flush(superHero1);
        });

        it('createSuperHero() return an error when the server returns a 404 error', (): void => {
            const hero: ISuperHero = {
                name: 'super man',
                description: 'A men with spider powers',
                id: 1,
            };

            service
                .createSuperHero(hero)
                .pipe(
                    catchError((error: HttpErrorResponse): Observable<never> => {
                        expect(error).toEqual(error);
                        return NEVER;
                    })
                )
                .subscribe();
            httpController
                .expectOne({
                    method: 'POST',
                })
                .flush('', {
                    status: 404,
                    statusText: 'Not Found',
                });
        });
    });

    describe('editSuperHero()', (): void => {
        it('should call editSuperHero  and edit a super hero', (): void => {
            const hero: ISuperHero = {
                name: 'super man',
                description: 'A men with spider powers',
                id: 1,
            };

            service.editSuperHero(hero, hero.id).subscribe((data: ISuperHero): void => {
                expect(data).toEqual(superHero1);
            });

            const req: TestRequest = httpController.expectOne({
                method: 'PUT',
                url: `${url}super-heroes/${hero.id}`,
            });

            req.flush(superHero1);
        });

        it('editSuperHero() return an error when the server returns a 404 error', (): void => {
            const hero: ISuperHero = {
                name: 'super man',
                description: 'A men with spider powers',
                id: 1,
            };

            service
                .editSuperHero(hero, hero.id)
                .pipe(
                    catchError((error: HttpErrorResponse): Observable<never> => {
                        expect(error).toEqual(error);
                        return NEVER;
                    })
                )
                .subscribe();
            httpController
                .expectOne({
                    method: 'PUT',
                })
                .flush('', {
                    status: 404,
                    statusText: 'Not Found',
                });
        });
    });

    describe('', (): void => {
        it('should call deleteSuperHero  and delete a super hero', (): void => {
            const id = 1;

            service.deleteSuperHero(id).subscribe((data: ISuperHero): void => {
                expect(data).toEqual(superHero1);
            });

            const req: TestRequest = httpController.expectOne({
                method: 'DELETE',
                url: `${url}super-heroes/${id}`,
            });

            req.flush(superHero1);
        });

        it('deleteSuperHero() return an error when the server returns a 404 error', (): void => {
            service
                .deleteSuperHero(1)
                .pipe(
                    catchError((error: HttpErrorResponse): Observable<never> => {
                        expect(error).toEqual(error);
                        return NEVER;
                    })
                )
                .subscribe();
            httpController
                .expectOne({
                    method: 'DELETE',
                })
                .flush('', {
                    status: 404,
                    statusText: 'Not Found',
                });
        });
    });
});
