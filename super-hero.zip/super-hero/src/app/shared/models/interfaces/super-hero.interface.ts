export interface ISuperHero {
    id: number;
    name: string;
    description?: string;
}

export interface ISuperHeroEdition {
    name: string;
    description?: string;
}
