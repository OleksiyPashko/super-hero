export interface IConfirmationModal {
    title: string;
    message: string;
}
