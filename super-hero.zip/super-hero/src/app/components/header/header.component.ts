import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ILanguage } from './models/interfaces/language.interface';
import { EEnglishLanguage, ESpanishLanguage } from './models/enums/language.enum';
import { LocalStorageService } from '../../shared/services/local-storage/local-storage.service';

const languageKey: string = 'language';

@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit {
    public readonly spanishLanguage: ILanguage = {
        code: ESpanishLanguage.CODE,
        label: ESpanishLanguage.LABEL,
    };

    public readonly englishLanguage: ILanguage = {
        code: EEnglishLanguage.CODE,
        label: EEnglishLanguage.LABEL,
    };

    public siteLanguage: ILanguage = this.englishLanguage;

    constructor(
        private readonly translateService: TranslateService,
        private readonly localStorageService: LocalStorageService
    ) {}

    public ngOnInit(): void {
        this.siteLanguage = (this.localStorageService.getObject(languageKey) as ILanguage) ?? this.englishLanguage;
        this.changeSiteLanguage(this.siteLanguage);
    }

    public changeSiteLanguage(language: ILanguage): void {
        this.siteLanguage = language;
        this.translateService.use(language.code);
        this.localStorageService.setObject(languageKey, language);
    }
}
