import {
    AfterViewInit,
    ChangeDetectionStrategy,
    ChangeDetectorRef,
    Component,
    OnDestroy,
    OnInit,
    ViewChild,
} from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { ISuperHero } from '../../shared/models/interfaces/super-hero.interface';
import { OptionalType } from '../../shared/models/types/optional.type';
import { first } from 'rxjs';
import { FormBuilder, FormControl } from '@angular/forms';
import { debounceTime } from 'rxjs/internal/operators/debounceTime';
import { distinctUntilChanged } from 'rxjs/internal/operators/distinctUntilChanged';
import { takeUntil } from 'rxjs/internal/operators/takeUntil';
import { Subject } from 'rxjs/internal/Subject';
import { switchMap } from 'rxjs/internal/operators/switchMap';
import { Observable } from 'rxjs/internal/Observable';
import { combineLatest } from 'rxjs/internal/observable/combineLatest';
import { startWith } from 'rxjs/internal/operators/startWith';
import { IConfirmationModal } from '../../shared/models/interfaces/confirmation-modal.interface';
import { EditCreateHeroService } from '../../shared/services/edit-create-hero/edit-create-hero.service';
import { SuperHeroHttpService } from '../../shared/services/super-hero-http/super-hero-http.service';
import { TranslateService } from '@ngx-translate/core';
import { ConfirmDialogModalService } from '../../shared/services/remove-hero-modal/confirm-dialog-modal.service';

@Component({
    selector: 'app-hero-list',
    templateUrl: './hero-list.component.html',
    styleUrls: ['./hero-list.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HeroListComponent implements OnInit, AfterViewInit, OnDestroy {
    public displayedColumns: string[] = ['id', 'name', 'description', 'actions'];
    public dataSource: MatTableDataSource<ISuperHero> = new MatTableDataSource<ISuperHero>();

    @ViewChild(MatPaginator) public paginator: OptionalType<MatPaginator>;
    @ViewChild(MatSort) public sort: OptionalType<MatSort>;
    public searchByNameControl: FormControl = this.formBuilder.control('');
    public searchByIdControl: FormControl = this.formBuilder.control('');
    private componentDestroyedSubject$: Subject<void> = new Subject<void>();

    constructor(
        private readonly superHeroHttpService: SuperHeroHttpService,
        private readonly formBuilder: FormBuilder,
        private readonly changeDetectorRef: ChangeDetectorRef,
        private readonly editCreateHeroService: EditCreateHeroService,
        private readonly confirmDialogModalService: ConfirmDialogModalService,
        private readonly translateService: TranslateService
    ) {}

    public ngOnInit(): void {
        this.getAllSuperHeroes();
        this.subscribeOnSearchControl();
    }

    public ngAfterViewInit(): void {
        this.initSort();
        this.initPaginator();
    }

    public subscribeOnSearchControl(): void {
        combineLatest([
            this.searchByNameControl.valueChanges.pipe(startWith('')),
            this.searchByIdControl.valueChanges.pipe(startWith('')),
        ])
            .pipe(
                debounceTime(500),
                distinctUntilChanged((previous: [string, string], current: [string, string]): boolean => {
                    const [previousName, previousId] = previous;
                    const [currentName, currentId] = current;

                    return !(previousName !== currentName || previousId !== currentId);
                }),
                switchMap((controlValue: [string, string]): Observable<ISuperHero[]> => {
                    return this.superHeroHttpService.searchHeroesByQuery(...controlValue);
                }),
                takeUntil(this.componentDestroyedSubject$)
            )
            .subscribe((superHeroesData: ISuperHero[]): void => {
                this.dataSource = new MatTableDataSource<ISuperHero>(superHeroesData);
                this.changeDetectorRef.detectChanges();
            });
    }

    public ngOnDestroy(): void {
        this.componentDestroyedSubject$.next();
        this.componentDestroyedSubject$.complete();
    }

    public clearFilters(): void {
        this.resetInputFields();
        this.getAllSuperHeroes();
    }

    public openCreateHeroModal(): void {
        this.resetInputFields();
        this.editCreateHeroService
            .openModal()
            .pipe(first())
            .subscribe((isSuccess: boolean): void => {
                if (isSuccess) {
                    this.getAllSuperHeroes();
                }
            });
    }

    public openEditHeroModal(id: number): void {
        this.resetInputFields();
        this.editCreateHeroService
            .openModal(id)
            .pipe(first())
            .subscribe((isSuccess: boolean): void => {
                if (isSuccess) {
                    this.getAllSuperHeroes();
                }
            });
    }

    public openRemoveConfirmDialog(id: number): void {
        const dialogData: IConfirmationModal = {
            title: this.translateService.instant('areYourSure'),
            message: this.translateService.instant('ifYouClickYesRemove'),
        };

        this.confirmDialogModalService.openModal(dialogData).subscribe((isDelete: boolean): void => {
            if (isDelete) {
                this.deleteSuperHero(id);
            }
        });
    }

    public deleteSuperHero(id: number): void {
        this.superHeroHttpService
            .deleteSuperHero(id)
            .pipe(first())
            .subscribe((): void => {
                this.getAllSuperHeroes();
            });
    }

    private resetInputFields(): void {
        this.searchByIdControl.reset();
        this.searchByNameControl.reset();
    }

    private getAllSuperHeroes(): void {
        this.superHeroHttpService
            .getAllSuperHeroes()
            .pipe(first())
            .subscribe((superHeroes: ISuperHero[]): void => {
                this.dataSource = new MatTableDataSource<ISuperHero>(superHeroes);
                this.changeDetectorRef.detectChanges();
            });
    }

    private initPaginator(): void {
        if (this.paginator) {
            this.dataSource.paginator = this.paginator;
        }
    }

    private initSort(): void {
        if (this.sort) {
            this.dataSource.sort = this.sort;
        }
    }
}
