export interface IEnvironment {
    production: boolean;
    httpServer: string;
}
